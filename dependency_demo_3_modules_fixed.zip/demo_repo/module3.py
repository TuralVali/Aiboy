"""ICAAP reporting and portfolio utilities."""

from module1 import customer_snapshot, customer_summary
from module2 import calculate_pd, calculate_expected_loss, build_risk_profile

def prepare_customer(customer_id):
    return customer_snapshot(customer_id)

def calculate_capital_charge(customer):
    return calculate_expected_loss(customer) * 0.08

def calculate_stress_capital(customer):
    return calculate_capital_charge(customer) * 1.5

def build_customer_report(customer_id):
    customer = prepare_customer(customer_id)
    return customer_summary(customer)

def build_risk_report(customer_id):
    customer = prepare_customer(customer_id)
    return build_risk_profile(customer)

def run_icaap_customer(customer_id):
    customer = prepare_customer(customer_id)
    pd = calculate_pd(customer)
    capital = calculate_capital_charge(customer)
    return {"customer": customer_id, "pd": pd, "capital": capital}

def aggregate_losses(customers):
    return sum(calculate_expected_loss(c) for c in customers)

def portfolio_risk(customers):
    return {"loss": aggregate_losses(customers), "count": len(customers)}

def portfolio_capital(customers):
    return portfolio_risk(customers)["loss"] * 0.08

def run_month_end(customer_ids):
    return [run_icaap_customer(cid) for cid in customer_ids]
