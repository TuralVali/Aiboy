"""Credit risk model utilities."""

from module1 import customer_snapshot, customer_is_active, get_customer_segment

def load_risk_factors(customer):
    return {"pd": 0.025, "lgd": 0.45, "ead": 100000}

def calculate_pd(customer):
    factors = load_risk_factors(customer)
    segment = get_customer_segment(customer)
    adjustment = 0.8 if segment == "PREMIUM" else 1.0
    return factors["pd"] * adjustment

def calculate_lgd(customer):
    factors = load_risk_factors(customer)
    return factors["lgd"]

def calculate_ead(customer):
    factors = load_risk_factors(customer)
    return factors["ead"]

def calculate_expected_loss(customer):
    return calculate_pd(customer) * calculate_lgd(customer) * calculate_ead(customer)

def risk_grade(pd):
    if pd < 0.01:
        return "LOW"
    if pd < 0.05:
        return "MEDIUM"
    return "HIGH"

def build_risk_profile(customer):
    pd = calculate_pd(customer)
    return {"pd": pd, "grade": risk_grade(pd)}

def is_risk_eligible(customer):
    return customer_is_active(customer) and calculate_pd(customer) < 0.10

def customer_risk_snapshot(customer_id):
    customer = customer_snapshot(customer_id)
    return build_risk_profile(customer)

def calculate_stress_loss(customer, multiplier=1.5):
    return calculate_expected_loss(customer) * multiplier
