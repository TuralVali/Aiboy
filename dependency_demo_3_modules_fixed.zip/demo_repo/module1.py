"""Customer and risk data utilities."""

def load_customer(customer_id):
    return {"id": customer_id}

def normalize_customer(customer):
    return {k: str(v).strip() for k, v in customer.items()}

def validate_customer(customer):
    return bool(customer.get("id"))

def get_customer_segment(customer):
    return "PREMIUM" if int(customer.get("score", 0)) >= 700 else "STANDARD"

def calculate_customer_score(customer):
    return min(850, max(300, int(customer.get("score", 500))))

def enrich_customer(customer):
    customer = normalize_customer(customer)
    customer["score"] = calculate_customer_score(customer)
    return customer

def customer_snapshot(customer_id):
    customer = load_customer(customer_id)
    return enrich_customer(customer)

def customer_is_active(customer):
    return validate_customer(customer) and customer.get("status") == "ACTIVE"

def customer_summary(customer):
    return {"id": customer["id"], "segment": get_customer_segment(customer)}
