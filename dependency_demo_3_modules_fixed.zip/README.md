# Dependency Map Demo

Repository:
- module1.py — customer utilities, 10 functions
- module2.py — credit risk utilities, 10 functions
- module3.py — ICAAP/reporting utilities, 10 functions

Target:
module2.calculate_pd

Outputs:
- output/dependency_graph.json
- output/dependency_map.html

Open dependency_map.html directly in a browser.
