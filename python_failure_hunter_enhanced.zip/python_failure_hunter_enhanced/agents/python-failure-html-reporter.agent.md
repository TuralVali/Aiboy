---
name: python-failure-html-reporter
description: Build a standalone interactive HTML dashboard from failure_report.json.
tools:
  - read
  - edit
---

# Python Failure HTML Reporter

Read `failure_report.json` and generate `failure_report.html`.

The report must be standalone and browser-openable.

## Dashboard

Show:

- target function
- total cases
- failures
- suspicious
- warnings
- robust
- coverage by category

## Categories

Support filters for:

- NA / Missing
- Empty DataFrame
- Division by Zero
- Type Mismatch
- Numeric Boundary
- Pandas
- NumPy
- String
- Collection / Shape
- Exceptions
- Domain Invariant

## Finding cards

Each finding must show:

- ID
- category
- severity/result
- input
- expected
- actual
- exception
- warnings
- dtype
- shape
- evidence
- minimal reproducer

Include:

- search
- result filter
- category filter
- expandable details
- copy reproducer
- responsive layout

Use a dark IDE-style design.

No external CDN or server.
Embed the report data directly in the HTML.
Important findings must remain readable without JavaScript.
