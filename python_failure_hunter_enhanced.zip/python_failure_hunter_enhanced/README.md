# Python Failure Hunter — Enhanced

Two GitHub Copilot agents:
- `python-failure-hunter.agent.md` — generates and executes adversarial tests.
- `python-failure-html-reporter.agent.md` — creates the interactive report.

The enhanced hunter explicitly checks NA values, empty DataFrames, division by zero,
type mismatches, string/numeric arithmetic, pandas alignment/dtypes, NumPy edge cases,
shape problems, exceptions, and domain invariants.
