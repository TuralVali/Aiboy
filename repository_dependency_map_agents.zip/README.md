# VS Code Repository Dependency Map Agents

## Files

- `agents/AGENT-1-Repository-Scanner.md` — scans the repository and creates `dependency_graph.json`.
- `agents/AGENT-2-HTML-Visualizer.md` — turns the graph into an interactive `dependency_map.html`.
- `sample/dependency_map.html` — standalone visual sample.

## Intended workflow

1. Give Agent 1 a target such as `models/pd.py:calculate_pd`.
2. Agent 1 performs static AST analysis.
3. Agent 1 creates `dependency_graph.json`.
4. Give the JSON to Agent 2.
5. Agent 2 creates the final interactive HTML.

The sample HTML can be opened directly in a browser.
