"""Offline tests; no real VM or user credentials are used."""
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from PySide6.QtWidgets import QApplication
from app import Window, Session, load_profiles, VerifyKey, Terminal
import paramiko

APP = QApplication.instance() or QApplication([])

class Tests(unittest.TestCase):
    def test_profiles_validation(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'profiles.json'
            for port in (0, 65536, True, '22'):
                path.write_text(json.dumps({'profiles':[dict(name='Cora', host='host', username='user', password='secret', port=port)]}))
                with self.assertRaises(ValueError):
                    load_profiles(path)
            path.write_text(json.dumps({'profiles':[dict(name='Cora', host='host', username='user', password='secret')]}))
            self.assertEqual(load_profiles(path)[0]['port'], 22)

    def test_alias_tabs_are_independent(self):
        with patch.object(Session, 'start', lambda self: None):
            w = Window()
            for i in range(4):
                w.list.setCurrentRow(i)
                w.connect_vm()
            self.assertEqual(len(w.sessions), 4)
            self.assertEqual(w.active()['profile']['host'], 'cora4.example.invalid')
            self.assertNotIn('password', w.active()['profile'])
            w.connect_vm()
            self.assertEqual(len(w.sessions), 4)
            for terminal in w.sessions:
                terminal.live = True
            current = w.tabs.currentWidget()
            w.send(current, b'pwd\r')
            self.assertEqual(w.active()['worker'].commands.get_nowait(), b'pwd\r')
            self.assertTrue(all(s['worker'].commands.empty() for s in w.sessions.values()))
            w.disconnect_vm()
            self.assertTrue(w.active()['worker'].stop.is_set())
            self.assertEqual(sum(s['worker'].stop.is_set() for s in w.sessions.values()), 1)
            for terminal in list(w.sessions):
                w.on_finished(terminal)
            w.close()

    def test_terminal_cursor_sequences(self):
        t = Terminal()
        t.reset()
        t.feed('hello\rWORLD')
        self.assertTrue(t.screen.display[0].startswith('WORLD'))

    def test_host_trust_rejection_and_persistence(self):
        with tempfile.TemporaryDirectory() as folder:
            w = Session({})
            w.known_hosts = Path(folder) / 'known_hosts'
            w.decision.set()
            key = paramiko.RSAKey.generate(2048)
            c = paramiko.SSHClient()
            with self.assertRaises(paramiko.SSHException):
                VerifyKey(w).missing_host_key(c, 'localhost', key)
            self.assertFalse(w.known_hosts.exists())
            w.accepted = True
            VerifyKey(w).missing_host_key(c, 'localhost', key)
            known = paramiko.HostKeys(str(w.known_hosts))
            self.assertTrue(known.check('localhost', key))

if __name__ == '__main__':
    unittest.main()
