# NEON / SSH

A Python desktop SSH workspace with a holographic interface, translucent navy panels, cyan borders and violet highlights, VM profiles, password authentication, and an embedded interactive shell. Runs locally on Windows, macOS, and Linux with Python 3.10+.

## Start

```bash
python -m venv .venv
```

Activate on Windows PowerShell with `.venv\Scripts\Activate.ps1`; on macOS/Linux use `source .venv/bin/activate`.

```bash
python -m pip install -r requirements.txt
```

Copy `profiles.example.json` to `profiles.json`. Replace the example host, username and password, then run:

```bash
python app.py
```

Alternatively use **Load JSON profiles** or `python app.py /path/to/profiles.json`. The default profile path is beside app.py, independent of the current directory. Click **Cora 1**, **Cora 2**, **Cora 3**, or **Cora 4** to open its terminal tab and connect. Clicking an already active machine focuses its tab. Disconnect affects only the current tab. Closing a session tab disconnects it. You can also select a machine with the keyboard and press **Connect**. The VM must be reachable (connect your VPN if required), run an SSH server, and permit password authentication.

## JSON format

```json
{
  "profiles": [
    {
      "name": "Development VM",
      "host": "192.168.1.50",
      "port": 22,
      "username": "ubuntu",
      "password": "YOUR_PASSWORD"
    }
  ]
}
```

Port defaults to 22. Multiple profiles are supported; independent concurrent terminal tabs. The app validates the file before replacing loaded profiles. It never edits your JSON. Password values must be JSON strings; escape backslashes and quotation marks correctly.

## Host identity and credentials

On first connection, compare the displayed SHA-256 host-key fingerprint with your VM console or administrator before accepting it. Accepted host keys are saved in `~/.neon_ssh/known_hosts`. Existing OpenSSH known hosts are also checked. A changed known key blocks the connection. If a VM is intentionally rebuilt, verify its new identity before manually removing its old known-host entry.

Passwords in JSON are **plain text**, as requested. Keep the file private, out of version control and shared folders. On macOS/Linux use `chmod 600 profiles.json`; on Windows restrict the file's access permissions to your account. Passwords are not displayed or written to logs by this app. Remote terminal output is displayed verbatim: commands you run can still print secrets.

## Terminal and scope

Type directly in the terminal. Enter, arrows, Tab, Backspace and Ctrl+A–Z are forwarded; Ctrl+C interrupts remote commands. Copy with Ctrl+Shift+C and paste with Ctrl+Shift+V or the Paste button. Multiline paste requires confirmation because newlines can execute commands.

The shell uses a fixed 110×30 VT100 screen with UTF-8 decoding and ANSI cursor processing through pyte. This first version renders monochrome text; it does not implement full xterm colors, mouse reporting, scrollback, automatic terminal resizing or every full-screen application's shortcut. Maximize the window or scroll horizontally to view the entire screen. Jump hosts, SSH config parsing, key authentication and MFA are not included.

SSH runs in a worker thread. Disconnect requests stop the session; while connecting, shutdown may wait for network/DNS/authentication timeouts. Closing the window waits for the worker rather than forcibly terminating it.

## Implementation references

- https://docs.paramiko.org/en/stable/api/client.html
- https://doc.qt.io/qtforpython-6.10/overviews/qtdoc-threads-qobject.html

See VALIDATION.md for the checks actually run on this package.

## Cora aliases

The four example profiles are named Cora 1–4. Replace each `host` with that VM's original IP address or resolvable hostname. For example `"alias": "cora4", "host": "10.20.30.44"` maps the Cora 4 profile to that address. The optional `alias` field is descriptive; selecting a sidebar profile resolves directly to its `host`, `port`, `username` and `password`. It does not execute Git Bash aliases or read your shell configuration. Existing aliases must have their real destination copied into this JSON. Example `.invalid` hosts deliberately cannot connect.

Each tab has an independent SSH shell and working directory. Commands such as `cd`, `ls`, `git status`, pipelines and Ctrl+C run on the VM, just as after `ssh` in Git Bash. This is not a local Git Bash installation; available commands depend on the VM.

## File manager

Click **Files / Transfer**. Choose any Cora on the left (source) and any Cora on the right (destination). Click Browse on each side; a blank folder opens the remote home directory. Double-click folders to navigate. Select one file or folder on the left, then use:

- **Copy → / Move →**: transfer the selected item, including a folder's descendants, into the right-hand folder. Choose the Coras in reverse order to transfer back. Files stream through the app in bounded chunks; there is no local disk staging. Existing destinations are rejected, never overwritten. Source and destination file contents are verified with SHA-256. Move removes the source only after verification.
- **Rename**: change the selected item's name within its current folder, without overwriting an existing destination.
- **Delete**: permanently remove the selected item; deleting a folder includes its contents. A confirmation names the exact source. No recycle bin or undo.
- **Change owner**: set numeric UID and GID on the selected file/folder. Run `id username` in the remote terminal to find IDs. No automatic sudo; the SSH account must already have permission.
- **Permissions**: set a three-digit Unix mode on the selected item, e.g. 640 for a file or 750 for a directory. This replaces existing owner/group/other permission bits. It is not recursive and does not manage named-user ACLs or default ACL inheritance. Directory execute permission is needed for traversal.

Each operation opens independent SFTP connections using the same JSON credentials and host verification as the terminals. Only one file job runs at a time. Browse again after an operation to refresh listings. Active file jobs must finish before closing the app or the file-manager tab.

### Transfer limits

Use quiescent source files: SFTP does not provide a transaction or lock against external writers. Snapshot and hash checks catch changes during copying, but cannot eliminate a race after final verification. A failure can leave a partial destination; deletion or the source-removal phase can be partially completed. Inspect both sides before retrying. No rollback is claimed. Symlinks and special files are rejected. Same configured host/port self-copy and descendant-copy are blocked; do not configure multiple names for the same server and use them to copy a directory into itself. Standard rwx bits are preserved, but ownership, timestamps, ACLs, extended attributes, sparse allocation and hard-link relationships are not. Destination ownership follows the destination login account.

Technical reference: https://docs.paramiko.org/en/stable/api/sftp.html
