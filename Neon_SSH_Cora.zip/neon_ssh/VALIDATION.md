# Validation

Passed four automated offline tests:
- JSON validation, invalid ports, and default port.
- Four independent Cora tabs, alias-to-host mapping, existing-tab reuse, per-tab keyboard input and disconnect isolation.
- Terminal carriage-return/cursor handling.
- Unknown host rejection and accepted host-key persistence.

The actual PySide6 application was launched with Qt's offscreen platform, rendered to preview.png, and visually inspected.

Run tests with `python -m unittest discover -s . -v` from this folder.

No real SSH endpoint was supplied, so live authentication, network disconnects and remote-shell compatibility have not been end-to-end verified. Test with a development VM before relying on it for regular work. The terminal limitations are listed in README.md.


File-manager update: all ten offline tests passed, including the original four plus recursive copy, verified move, failed-verification source retention, no-overwrite behavior, symlink/root rejection, recursive removal and permission-error handling. File operations were exercised through an SFTP-shaped local filesystem adapter, not a real SFTP server. The new file-manager tab was rendered and visually inspected. Real Cora authentication, SFTP service behavior, chmod and chown remain unverified against the user's VMs.
