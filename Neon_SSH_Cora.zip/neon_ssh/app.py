"""NEON / SSH — desktop SSH workspace. Python 3.10+."""
import base64
import codecs
import hashlib
import json
import queue
import sys
import threading
from pathlib import Path

import paramiko
import pyte
from file_manager import FileManager
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QFont, QTextCursor, QPainter, QColor, QPen, QLinearGradient, QRadialGradient
from PySide6.QtWidgets import (QApplication, QFileDialog, QFrame, QHBoxLayout,
    QLabel, QListWidget, QMainWindow, QMessageBox, QPlainTextEdit,
    QPushButton, QVBoxLayout, QWidget, QTabWidget)


HOST_LOCK = threading.Lock()

def load_profiles(path):
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    profiles = data.get('profiles') if isinstance(data, dict) else None
    if not isinstance(profiles, list) or not profiles:
        raise ValueError('Expected a nonempty "profiles" array.')
    result = []
    for i, p in enumerate(profiles, 1):
        if not isinstance(p, dict):
            raise ValueError(f'Profile {i} must be an object.')
        for key in ('name', 'host', 'username', 'password'):
            if not isinstance(p.get(key), str) or not p[key]:
                raise ValueError(f'Profile {i}: {key} must be a nonempty string.')
        port = p.get('port', 22)
        if type(port) is not int or not 1 <= port <= 65535:
            raise ValueError(f'Profile {i}: port must be an integer from 1 to 65535.')
        result.append({**p, 'port': port})
    return result


class VerifyKey(paramiko.MissingHostKeyPolicy):
    def __init__(self, worker):
        self.worker = worker

    def missing_host_key(self, client, hostname, key):
        w = self.worker
        fp = base64.b64encode(hashlib.sha256(key.asbytes()).digest()).decode().rstrip('=')
        w.trust_request.emit(hostname, key.get_name(), 'SHA256:' + fp)
        while not w.decision.wait(.1):
            if w.stop.is_set():
                raise paramiko.SSHException('Connection cancelled.')
        if not w.accepted or w.stop.is_set():
            raise paramiko.SSHException('Host key was not accepted.')
        with HOST_LOCK:
            known = paramiko.HostKeys()
            if w.known_hosts.exists():
                known.load(str(w.known_hosts))
            existing = known.lookup(hostname)
            if existing and key.get_name() in existing and existing[key.get_name()] != key:
                raise paramiko.SSHException('Conflicting host key.')
            known.add(hostname, key.get_name(), key)
            known.save(str(w.known_hosts))
            w.known_hosts.chmod(0o600)
        client.get_host_keys().add(hostname, key.get_name(), key)


class Session(QThread):
    output = Signal(str)
    connected = Signal()
    error = Signal(str)
    trust_request = Signal(str, str, str)

    def __init__(self, profile, parent=None):
        super().__init__(parent)
        self.profile = dict(profile)
        self.stop = threading.Event()
        self.decision = threading.Event()
        self.accepted = False
        self.commands = queue.Queue(maxsize=1024)
        self.known_hosts = Path.home() / '.neon_ssh' / 'known_hosts'

    def run(self):
        client = paramiko.SSHClient()
        try:
            self.known_hosts.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            client.load_system_host_keys()
            with HOST_LOCK:
                if self.known_hosts.exists():
                    client.load_host_keys(str(self.known_hosts))
            client.set_missing_host_key_policy(VerifyKey(self))
            p = self.profile
            client.connect(p['host'], port=p['port'], username=p['username'],
                           password=p['password'], allow_agent=False, look_for_keys=False,
                           timeout=10, banner_timeout=10, auth_timeout=10, channel_timeout=10)
            if self.stop.is_set():
                return
            client.get_transport().set_keepalive(30)
            channel = client.invoke_shell(term='vt100', width=110, height=30)
            channel.settimeout(2)
            self.connected.emit()
            decoder = codecs.getincrementaldecoder('utf-8')(errors='replace')
            while not self.stop.is_set():
                for _ in range(64):
                    try:
                        data = self.commands.get_nowait()
                    except queue.Empty:
                        break
                    channel.sendall(data)
                if channel.recv_ready():
                    data = channel.recv(32768)
                    if not data:
                        break
                    self.output.emit(decoder.decode(data))
                elif channel.closed or channel.exit_status_ready() or not client.get_transport().is_active():
                    break
                else:
                    self.stop.wait(.02)
        except paramiko.BadHostKeyException:
            self.error.emit('HOST KEY CHANGED. Connection blocked. Verify the VM identity with its administrator.')
        except paramiko.AuthenticationException:
            self.error.emit('Authentication failed. Check the username/password and SSH password login settings.')
        except Exception as exc:
            if not self.stop.is_set():
                # Do not display raw server messages, which may contain sensitive text.
                self.error.emit(f'Connection failed ({type(exc).__name__}). Check the host, port, VPN and SSH service.')
        finally:
            client.close()
            self.profile.clear()


class Terminal(QPlainTextEdit):
    send = Signal(bytes)

    def __init__(self):
        super().__init__()
        self.setReadOnly(True)
        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.setFont(QFont('DejaVu Sans Mono', 11))
        self.setObjectName('terminal')
        self.screen = pyte.Screen(110, 30)
        self.stream = pyte.Stream(self.screen)
        self.live = False
        self.setPlainText('  NEON / SSH\n\n  Your next session starts here.\n\n  Select a VM, then press Connect.\n  Or load your own profiles.json file.\n\n  Passwords are never displayed in the connection panel.')

    def reset(self):
        self.screen.reset()
        self.setPlainText('')

    def feed(self, text):
        self.stream.feed(text)
        self.setPlainText('\n'.join(self.screen.display))
        cursor = self.textCursor()
        cursor.setPosition(self.screen.cursor.y * 111 + self.screen.cursor.x)
        self.setTextCursor(cursor)

    def keyPressEvent(self, event):
        mods = event.modifiers()
        if mods & Qt.ControlModifier and mods & Qt.ShiftModifier:
            if event.key() == Qt.Key_C:
                self.copy()
                return
            if event.key() == Qt.Key_V:
                self.paste_remote()
                return
        if not self.live:
            return super().keyPressEvent(event)
        keys = {Qt.Key_Return:'\r', Qt.Key_Enter:'\r', Qt.Key_Backspace:'\x7f',
                Qt.Key_Tab:'\t', Qt.Key_Escape:'\x1b', Qt.Key_Up:'\x1b[A',
                Qt.Key_Down:'\x1b[B', Qt.Key_Right:'\x1b[C', Qt.Key_Left:'\x1b[D',
                Qt.Key_Home:'\x1b[H', Qt.Key_End:'\x1b[F', Qt.Key_Delete:'\x1b[3~'}
        if mods & Qt.ControlModifier and Qt.Key_A <= event.key() <= Qt.Key_Z:
            text = chr(event.key() - Qt.Key_A + 1)
        else:
            text = keys.get(event.key(), event.text())
        if text:
            self.send.emit(text.encode('utf-8'))

    def paste_remote(self):
        if not self.live:
            return
        text = QApplication.clipboard().text()
        if len(text) > 16000:
            QMessageBox.warning(self, 'Paste too large', 'Paste at most 16,000 characters at once.')
            return
        if '\n' in text or '\r' in text:
            if QMessageBox.question(self, 'Paste multiple lines?',
                    'Newlines may execute commands immediately. Continue?',
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                return
        self.send.emit(text.encode('utf-8'))


STYLE = '''
QWidget {background:transparent;color:#d7f1ff;font-family:"Segoe UI";font-size:13px;}
QFrame#sidebar {background:rgba(7,20,39,205);border-right:1px solid #245069;}
QLabel {background:transparent;}
QLabel#logo {font-size:27px;font-weight:800;color:#87f0ff;letter-spacing:3px;}
QLabel#muted {color:#7fabc0;font-size:12px;}
QLabel#title {font-size:30px;font-weight:700;color:#e1f7ff;}
QLabel#badge {background:rgba(32,71,91,130);color:#91c8e0;border:1px solid #39657d;border-radius:10px;padding:7px 12px;}
QFrame#card {background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 rgba(31,86,112,150),stop:0.5 rgba(16,39,65,180),stop:1 rgba(60,44,104,140));border:1px solid #426f91;border-radius:14px;}
QListWidget {background:transparent;border:0;outline:0;}
QListWidget::item {padding:17px 12px;margin:5px 0;border-radius:9px;color:#8eb2c7;}
QListWidget::item:hover {background:rgba(37,91,119,80);}
QListWidget::item:selected {background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 rgba(39,139,169,120),stop:1 rgba(68,48,126,100));color:#bcf9ff;border:1px solid #3e8ca8;border-left:3px solid #77e8ff;}
QPushButton {background:rgba(22,53,78,180);border:1px solid #3c738c;border-radius:8px;padding:11px 17px;font-weight:600;color:#b4dce9;}
QPushButton:hover {background:rgba(38,101,128,190);border-color:#85dced;}
QPushButton:disabled {color:#536f85;border-color:#30475b;background:rgba(15,31,49,100);}
QPushButton#connect {background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #8aeaff,stop:0.5 #8dbef9,stop:1 #b6a5f4);color:#102c46;border:1px solid #c7f5ff;}
QPushButton#connect:hover {background:#b9f0ff;}
QPushButton#connect:disabled {background:#254157;color:#7899af;border:1px solid #42627b;}
QTabWidget::pane {border:0;}
QTabBar::tab {background:rgba(17,36,61,190);color:#759db6;padding:12px 22px;margin-right:4px;border-top-left-radius:7px;border-top-right-radius:7px;border:1px solid #2a4c68;}
QTabBar::tab:selected {background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #183f58,stop:1 #30294f);color:#a0f2ff;border-bottom:2px solid #77d8f2;}
QPlainTextEdit#terminal {background:rgba(5,18,33,205);border:1px solid #37647e;border-radius:12px;padding:18px;color:#a2e2f4;font-family:monospace;selection-background-color:#375678;}
QScrollBar:vertical {background:#112437;width:10px;}
QScrollBar::handle:vertical {background:#3d6b83;min-height:25px;}
'''


class HoloBackground(QWidget):
    """Paint a subtle holographic grid beneath translucent Qt panels."""
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        base = QLinearGradient(0, 0, self.width(), self.height())
        base.setColorAt(0, QColor('#071827'))
        base.setColorAt(.5, QColor('#0c2036'))
        base.setColorAt(1, QColor('#171730'))
        painter.fillRect(self.rect(), base)
        for x, y, radius, color in [(.78,.18,420,'#286c8d'),(.95,.78,380,'#563e87'),(.3,.9,350,'#16576b')]:
            glow = QRadialGradient(self.width()*x,self.height()*y,radius)
            c=QColor(color);c.setAlpha(85)
            glow.setColorAt(0,c);glow.setColorAt(1,QColor(0,0,0,0))
            painter.fillRect(self.rect(),glow)
        painter.setPen(QPen(QColor(105,190,220,16),1))
        for x in range(255,self.width(),44):
            painter.drawLine(x,0,x,self.height())
        for y in range(0,self.height(),44):
            painter.drawLine(255,y,self.width(),y)
        # Thin concentric instrument arcs in the background.
        painter.setPen(QPen(QColor(110,206,236,24),1))
        for radius in (160,184,225):
            painter.drawEllipse(self.width()-radius-75,55-radius,2*radius,2*radius)
        painter.end()



def label(text, name=None):
    obj = QLabel(text)
    obj.setTextFormat(Qt.PlainText)
    if name:
        obj.setObjectName(name)
    return obj


class Window(QMainWindow):
    def __init__(self, path=None):
        super().__init__()
        self.sessions = {}
        self.file_manager = None
        self.profiles = []
        self.closing = False
        self.setWindowTitle('NEON / SSH · VM workspace')
        self.resize(1280, 820)
        self.setMinimumSize(960, 650)
        root = HoloBackground()
        self.setCentralWidget(root)
        layout = QHBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        sidebar = QFrame()
        sidebar.setObjectName('sidebar')
        sidebar.setFixedWidth(255)
        left = QVBoxLayout(sidebar)
        left.setContentsMargins(22, 30, 22, 25)
        left.addWidget(label('NEON / SSH', 'logo'))
        left.addWidget(label('HOLOGRAPHIC WORKSPACE', 'muted'))
        left.addSpacing(40)
        left.addWidget(label('SAVED MACHINES', 'muted'))
        self.list = QListWidget()
        self.list.currentRowChanged.connect(self.select)
        self.list.itemClicked.connect(lambda _: self.connect_vm())
        left.addWidget(self.list)
        self.load_button = QPushButton('+  Load JSON profiles')
        self.load_button.clicked.connect(self.choose_file)
        left.addWidget(self.load_button)
        left.addSpacing(15)
        left.addWidget(label('◈  LOCAL PROFILES  /  SSH 2', 'muted'))
        layout.addWidget(sidebar)
        body = QVBoxLayout()
        body.setContentsMargins(32, 28, 32, 22)
        body.setSpacing(18)
        layout.addLayout(body, 1)
        top = QHBoxLayout()
        top.addWidget(label('Connection studio', 'title'))
        top.addStretch()
        self.status = label('●  Offline', 'badge')
        top.addWidget(self.status)
        body.addLayout(top)
        body.addWidget(label('REMOTE ACCESS  /  FOUR NODES  /  ONE WORKSPACE', 'muted'))
        card = QFrame()
        card.setObjectName('card')
        row = QHBoxLayout(card)
        row.setContentsMargins(22, 20, 22, 20)
        self.details = []
        for title in ('MACHINE', 'ENDPOINT', 'IDENTITY'):
            col = QVBoxLayout()
            col.addWidget(label(title, 'muted'))
            value = label('—')
            self.details.append(value)
            col.addWidget(value)
            row.addLayout(col, 1)
        body.addWidget(card)
        buttons = QHBoxLayout()
        self.connect_button = QPushButton('Connect  ↗')
        self.connect_button.setObjectName('connect')
        self.connect_button.clicked.connect(self.connect_vm)
        self.disconnect_button = QPushButton('Disconnect')
        self.disconnect_button.setEnabled(False)
        self.disconnect_button.clicked.connect(self.disconnect_vm)
        buttons.addWidget(self.connect_button)
        buttons.addWidget(self.disconnect_button)
        files = QPushButton('Files / Transfer  ⇄')
        files.clicked.connect(self.open_files)
        buttons.addWidget(files)
        buttons.addStretch()
        buttons.addWidget(label('PASSWORD AUTHENTICATION', 'muted'))
        body.addLayout(buttons)
        header = QHBoxLayout()
        header.addWidget(label('●  ●  ●     TERMINAL / LIVE SHELL', 'muted'))
        header.addStretch()
        paste = QPushButton('Paste')
        paste.clicked.connect(self.paste_active)
        header.addWidget(paste)
        body.addLayout(header)
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.welcome = Terminal()
        self.tabs.addTab(self.welcome, 'Welcome')
        body.addWidget(self.tabs, 1)
        self.note = label('Ready  ·  Select a machine to begin   |   Ctrl+Shift+C copy · Ctrl+Shift+V paste', 'muted')
        self.note.setWordWrap(True)
        body.addWidget(self.note)
        self.tabs.currentChanged.connect(self.tab_changed)
        self.setStyleSheet(STYLE)
        default = Path(__file__).with_name('profiles.json')
        if not default.exists():
            default = Path(__file__).with_name('profiles.example.json')
        if path or default.exists():
            self.load(path or default)
        self.select(self.list.currentRow())

    def open_files(self):
        if not self.profiles:
            return
        if self.file_manager is None:
            self.file_manager = FileManager(self.profiles, VerifyKey, HOST_LOCK, self.verify, self)
            self.tabs.addTab(self.file_manager, 'Files / Transfer')
        self.tabs.setCurrentWidget(self.file_manager)

    def choose_file(self):
        if self.file_manager and self.file_manager.job:
            QMessageBox.information(self, 'File operation running', 'Wait for the file operation to finish before loading profiles.')
            return
        path, _ = QFileDialog.getOpenFileName(self, 'Load VM profiles', '', 'JSON files (*.json)')
        if path:
            self.load(path)

    def load(self, path):
        try:
            profiles = load_profiles(path)
        except (OSError, ValueError, UnicodeError) as exc:
            message = str(exc) if isinstance(exc, ValueError) and not isinstance(exc, json.JSONDecodeError) else 'Cannot read profiles. Check the file and JSON syntax.'
            QMessageBox.warning(self, 'Invalid profile file', message)
            return
        if self.file_manager:
            self.remove_tab(self.file_manager)
            self.file_manager = None
        self.list.clear()
        self.profiles = profiles
        self.list.addItems([p['name'] for p in profiles])
        self.list.setCurrentRow(0)

    def select(self, index):
        if 0 <= index < len(self.profiles):
            p = self.profiles[index]
            for obj, text in zip(self.details, (p['name'], f"{p['host']}:{p['port']}", p['username'])):
                obj.setText(text)
                obj.setToolTip(text)
        self.connect_button.setEnabled(index >= 0 and not self.closing)

    def active(self):
        return self.sessions.get(self.tabs.currentWidget())

    def paste_active(self):
        terminal = self.tabs.currentWidget()
        if isinstance(terminal, Terminal):
            terminal.paste_remote()

    def tab_changed(self, index):
        state = self.active()
        self.disconnect_button.setEnabled(bool(state and state['worker'] and not state['worker'].stop.is_set()))
        self.status.setText(state['status'] if state else '●  Offline')
        self.note.setText(state['note'] if state else 'Select Cora 1–4 to open a connected terminal tab.')
        if state:
            p = state['profile']
            for obj, text in zip(self.details, (p['name'], f"{p['host']}:{p['port']}", p['username'])):
                obj.setText(text)

    def connect_vm(self):
        index = self.list.currentRow()
        if index < 0 or self.closing:
            return
        p = self.profiles[index]
        identity = (p['name'], p['host'], p['port'], p['username'])
        for terminal, state in self.sessions.items():
            if state['identity'] == identity and state['worker']:
                self.tabs.setCurrentWidget(terminal)
                return
        terminal = Terminal()
        terminal.reset()
        worker = Session(p, self)
        state = {'worker': worker, 'profile': {k:v for k,v in p.items() if k != 'password'},
                 'identity': identity, 'status': '◌  Connecting',
                 'note': f"Connecting to {p['name']} → {p['host']}:{p['port']}…", 'close': False}
        self.sessions[terminal] = state
        worker.output.connect(terminal.feed)
        worker.connected.connect(lambda: self.on_connected(terminal))
        worker.error.connect(lambda message: self.on_error(terminal, message))
        worker.trust_request.connect(lambda host, algorithm, fp: self.verify(worker, host, algorithm, fp))
        worker.finished.connect(lambda: self.on_finished(terminal))
        terminal.send.connect(lambda data: self.send(terminal, data))
        self.tabs.addTab(terminal, p['name'])
        self.tabs.setCurrentWidget(terminal)
        worker.start()

    def verify(self, worker, host, algorithm, fingerprint):
        if worker.stop.is_set():
            return
        answer = QMessageBox.question(self, 'Verify this VM',
            f'First connection to {host}\n\n{algorithm}\n{fingerprint}\n\nCompare this fingerprint with your VM administrator or console. Trust and save this host key?',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        worker.accepted = answer == QMessageBox.Yes
        worker.decision.set()

    def on_connected(self, terminal):
        state = self.sessions[terminal]
        if state['worker'].stop.is_set():
            return
        state['status'] = '●  Connected'
        state['note'] = 'Live remote shell  ·  Ctrl+C interrupts  ·  Ctrl+Shift+C copies  ·  Ctrl+Shift+V pastes'
        terminal.live = True
        self.tab_changed(self.tabs.currentIndex())
        if self.tabs.currentWidget() is terminal:
            terminal.setFocus()

    def on_error(self, terminal, message):
        state = self.sessions[terminal]
        state['note'] = message
        state['error'] = True
        self.tab_changed(self.tabs.currentIndex())
        QMessageBox.warning(self, state['profile']['name'] + ' / SSH', message)

    def send(self, terminal, data):
        state = self.sessions.get(terminal)
        if state and state['worker'] and terminal.live:
            try:
                state['worker'].commands.put_nowait(data)
            except queue.Full:
                state['note'] = 'Input buffer full. Wait for the connection to respond.'
                self.tab_changed(self.tabs.currentIndex())

    def stop_session(self, terminal):
        state = self.sessions.get(terminal)
        if state and state['worker']:
            state['worker'].stop.set()
            state['worker'].decision.set()
            terminal.live = False
            state['status'] = '◌  Disconnecting'
            state['note'] = 'Closing SSH session… Network timeouts may take several seconds.'
            self.tab_changed(self.tabs.currentIndex())

    def disconnect_vm(self):
        self.stop_session(self.tabs.currentWidget())

    def close_tab(self, index):
        terminal = self.tabs.widget(index)
        if terminal is self.file_manager and self.file_manager.job:
            QMessageBox.information(self, 'File operation running', 'Wait for the file operation to finish before closing this tab.')
            return
        state = self.sessions.get(terminal)
        if state and state['worker']:
            state['close'] = True
            self.stop_session(terminal)
        else:
            self.remove_tab(terminal)

    def remove_tab(self, terminal):
        if terminal is self.file_manager:
            self.file_manager = None
        self.sessions.pop(terminal, None)
        self.tabs.removeTab(self.tabs.indexOf(terminal))
        terminal.deleteLater()

    def on_finished(self, terminal):
        state = self.sessions[terminal]
        state['worker'].deleteLater()
        state['worker'] = None
        state['status'] = '●  Offline'
        if not state.get('error'):
            state['note'] = 'Session ended. Click the machine to reconnect in a new tab.'
        terminal.live = False
        if state['close']:
            self.remove_tab(terminal)
        self.tab_changed(self.tabs.currentIndex())
        if self.closing and not any(s['worker'] for s in self.sessions.values()):
            self.close()

    def closeEvent(self, event):
        if self.file_manager and self.file_manager.job:
            QMessageBox.information(self, 'File operation running', 'Wait for the file operation to finish before closing the app.')
            event.ignore()
            return
        if any(s['worker'] for s in self.sessions.values()):
            self.closing = True
            for terminal in list(self.sessions):
                self.stop_session(terminal)
            event.ignore()
        else:
            event.accept()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Window(sys.argv[1] if len(sys.argv) > 1 else None)
    window.show()
    sys.exit(app.exec())
