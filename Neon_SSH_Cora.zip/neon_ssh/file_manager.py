"""SFTP file manager. No shell interpolation or implicit privilege escalation."""
import errno
import hashlib
import posixpath as pp
import stat
from pathlib import Path
import threading

import paramiko
from PySide6.QtCore import QThread, Signal, Qt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QLineEdit, QTreeWidget, QTreeWidgetItem,
    QInputDialog, QMessageBox, QAbstractItemView)


def absent(sftp, path):
    try:
        sftp.lstat(path)
    except OSError as exc:
        if exc.errno == errno.ENOENT:
            return
        raise
    raise ValueError('Destination already exists. Choose a different name; overwriting is disabled.')


def safe_path(path):
    if not path.startswith('/') or pp.normpath(path) in ('/', '//') or '\x00' in path:
        raise ValueError('Select an absolute non-root path.')
    return pp.normpath(path)


def snapshot(sftp, root):
    """Record a tree without following symlinks or accepting special files."""
    records = {}
    def visit(path, rel):
        a = sftp.lstat(path)
        if not (stat.S_ISDIR(a.st_mode) or stat.S_ISREG(a.st_mode)):
            raise ValueError('Symlinks and special files are not supported for this operation.')
        records[rel] = (a.st_mode, a.st_size, a.st_mtime)
        if stat.S_ISDIR(a.st_mode):
            for child in sftp.listdir_attr(path):
                if child.filename in ('.', '..') or '/' in child.filename:
                    raise ValueError('Invalid server filename.')
                visit(pp.join(path, child.filename), pp.join(rel, child.filename))
    visit(root, '')
    return records


def digest(sftp, path):
    h = hashlib.sha256()
    with sftp.open(path, 'rb') as f:
        while True:
            block = f.read(256 * 1024)
            if not block:
                return h.digest()
            h.update(block)


def remove_tree(sftp, root, records):
    for rel, info in sorted(records.items(), key=lambda v: v[0].count('/') + bool(v[0]), reverse=True):
        path = pp.join(root, rel) if rel else root
        current = sftp.lstat(path)
        if stat.S_IFMT(current.st_mode) != stat.S_IFMT(info[0]):
            raise ValueError('Source type changed. Removal stopped.')
        if stat.S_ISDIR(info[0]):
            sftp.rmdir(path)
        else:
            sftp.remove(path)


def transfer(source, target, src, dst, move=False, progress=lambda text: None):
    src, dst = safe_path(src), safe_path(dst)
    absent(target, dst)
    records = snapshot(source, src)
    hashes = {}
    # Exclusive creates prevent silently replacing another file.
    for rel, info in records.items():
        a = pp.join(src, rel) if rel else src
        b = pp.join(dst, rel) if rel else dst
        progress('Copying ' + (rel or pp.basename(src)))
        if stat.S_ISDIR(info[0]):
            target.mkdir(b, 0o700)
        else:
            h = hashlib.sha256()
            with source.open(a, 'rb') as read, target.open(b, 'wx') as write:
                while True:
                    block = read.read(256 * 1024)
                    if not block:
                        break
                    write.write(block)
                    h.update(block)
            target.chmod(b, stat.S_IMODE(info[0]) & 0o777)
            hashes[rel] = h.digest()
            if digest(target, b) != hashes[rel]:
                raise ValueError('Destination checksum mismatch. Source retained.')
    if snapshot(source, src) != records:
        raise ValueError('Source changed during transfer. Source retained.')
    # Re-read source files too; size/mtime alone cannot detect every edit.
    for rel, expected in hashes.items():
        if digest(source, pp.join(src, rel) if rel else src) != expected:
            raise ValueError('Source content changed. Source retained.')
    for rel, info in reversed(list(records.items())):
        if stat.S_ISDIR(info[0]):
            target.chmod(pp.join(dst, rel) if rel else dst, stat.S_IMODE(info[0]) & 0o777)
    if move:
        progress('Copy verified. Removing source…')
        remove_tree(source, src, records)


class FileJob(QThread):
    result = Signal(object)
    failure = Signal(str)
    progress = Signal(str)
    trust_request = Signal(str, str, str)

    def __init__(self, profiles, policy, lock, operation, args):
        super().__init__()
        self.profiles = [dict(p) for p in profiles]
        self.policy, self.lock = policy, lock
        self.operation, self.args = operation, args
        self.stop = threading.Event()
        self.decision = threading.Event()
        self.accepted = False
        self.known_hosts = Path.home() / '.neon_ssh' / 'known_hosts'

    def connect_sftp(self, p, clients):
        c = paramiko.SSHClient()
        clients.append(c)
        self.known_hosts.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        c.load_system_host_keys()
        with self.lock:
            if self.known_hosts.exists():
                c.load_host_keys(str(self.known_hosts))
        self.decision.clear()
        self.accepted = False
        c.set_missing_host_key_policy(self.policy(self))
        c.connect(p['host'], port=p['port'], username=p['username'], password=p['password'],
                  allow_agent=False, look_for_keys=False, timeout=10, banner_timeout=10,
                  auth_timeout=10, channel_timeout=10)
        c.get_transport().set_keepalive(30)
        s = c.open_sftp()
        s.get_channel().settimeout(30)
        return s

    def run(self):
        clients = []
        try:
            s = self.connect_sftp(self.profiles[0], clients)
            op, args = self.operation, self.args
            if op == 'list':
                path = s.normalize(args['path'] or '.')
                entries = s.listdir_attr(path)
                self.result.emit((path, entries))
                return
            src = safe_path(args['src'])
            # Reject symbolic link targets, including a symlink selected as a folder.
            if stat.S_ISLNK(s.lstat(src).st_mode):
                raise ValueError('Select the real file or folder, not a symbolic link.')
            src = safe_path(s.normalize(src))
            if op in ('copy', 'move'):
                t = self.connect_sftp(self.profiles[1], clients)
                dst = safe_path(pp.join(t.normalize(args['dest_dir']), pp.basename(src)))
                a, b = self.profiles
                if (a['host'].lower(), a['port']) == (b['host'].lower(), b['port']):
                    if dst == src or dst.startswith(src.rstrip('/') + '/'):
                        raise ValueError('Cannot copy/move into the same path or its descendants.')
                transfer(s, t, src, dst, op == 'move', self.progress.emit)
            elif op == 'rename':
                dst = pp.join(pp.dirname(src), args['name'])
                absent(s, dst)
                s.rename(src, dst)
            elif op == 'delete':
                remove_tree(s, src, snapshot(s, src))
            elif op == 'chmod':
                s.chmod(src, args['mode'])
            elif op == 'chown':
                s.chown(src, args['uid'], args['gid'])
            self.result.emit('Completed: ' + op)
        except Exception as exc:
            if isinstance(exc, ValueError):
                message = str(exc)
            elif isinstance(exc, paramiko.BadHostKeyException):
                message = 'Host key changed. Connection blocked.'
            elif isinstance(exc, paramiko.AuthenticationException):
                message = 'Authentication failed.'
            elif isinstance(exc, OSError) and exc.errno == errno.EACCES:
                message = 'Permission denied. This account lacks the required access.'
            else:
                message = f'Operation failed ({type(exc).__name__}). Check connection, paths and account permissions.'
            self.failure.emit(message + '\nA failed transfer can leave a partial destination. A failed delete or source-removal step can be partial; inspect both sides before retrying.')
        finally:
            for c in clients:
                c.close()
            self.profiles.clear()


class FileManager(QWidget):
    def __init__(self, profiles, policy, lock, verify, parent=None):
        super().__init__(parent)
        self.profiles, self.policy, self.lock, self.verify = profiles, policy, lock, verify
        self.job = None
        self.panes = []
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel('FILE TRANSFER  /  Select an item on the left. Choose a destination folder on the right.'))
        columns = QHBoxLayout()
        for side in range(2):
            col = QVBoxLayout()
            combo = QComboBox()
            combo.addItems([p['name'] for p in profiles])
            combo.setCurrentIndex(min(side, len(profiles)-1))
            col.addWidget(combo)
            bar = QHBoxLayout()
            path = QLineEdit()
            path.setPlaceholderText('Remote folder (blank = home)')
            browse = QPushButton('Browse')
            bar.addWidget(path, 1); bar.addWidget(browse)
            col.addLayout(bar)
            tree = QTreeWidget()
            tree.setHeaderLabels(['Name', 'Bytes', 'Mode', 'UID:GID'])
            tree.setSelectionMode(QAbstractItemView.SingleSelection)
            tree.setColumnWidth(0, 200)
            tree.setMinimumHeight(200)
            col.addWidget(tree)
            columns.addLayout(col, 1)
            self.panes.append((combo, path, tree))
            browse.clicked.connect(lambda checked=False, i=side: self.browse(i))
            path.returnPressed.connect(lambda i=side: self.browse(i))
            combo.currentIndexChanged.connect(lambda _, i=side: self.reset_pane(i))
            tree.itemDoubleClicked.connect(lambda item, column, i=side: self.enter(i, item))
        layout.addLayout(columns, 1)
        actions = QHBoxLayout()
        for title, action in [('Copy →', 'copy'), ('Move →', 'move'), ('Rename', 'rename'),
                              ('Delete', 'delete'), ('Change owner', 'chown'), ('Permissions', 'chmod')]:
            button = QPushButton(title)
            button.clicked.connect(lambda checked=False, op=action: self.act(op))
            actions.addWidget(button)
        layout.addLayout(actions)
        self.status = QLabel('Ready · Select either Cora on either side · Ownership and permissions apply to the selected item only.')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.setStyleSheet('QLineEdit,QComboBox,QTreeWidget {background:#10273b;color:#b9eaff;border:1px solid #37647e;border-radius:5px;padding:7px;} QHeaderView::section {background:#183950;color:#b9eaff;padding:6px;border:0;} QTreeWidget::item:selected {background:#275573;}')

    def reset_pane(self, side):
        _, path, tree = self.panes[side]
        path.clear(); tree.clear()

    def enter(self, side, item):
        data = item.data(0, Qt.UserRole)
        if data and data[1]:
            self.panes[side][1].setText(data[0]); self.browse(side)

    def browse(self, side):
        combo, path, _ = self.panes[side]
        self.start('list', [self.profiles[combo.currentIndex()]], {'path': path.text()}, side)

    def start(self, op, profiles, args, side=None):
        if self.job:
            return
        self.setEnabled(False)
        self.status.setText('Connecting…' if op == 'list' else 'Running ' + op + '…')
        self.job = FileJob(profiles, self.policy, self.lock, op, args)
        self.job.trust_request.connect(lambda host, alg, fp: self.verify(self.job, host, alg, fp))
        self.job.progress.connect(self.status.setText)
        self.job.result.connect(lambda result: self.done(result, side))
        self.job.failure.connect(self.failed)
        self.job.finished.connect(self.finished)
        self.job.start()

    def done(self, result, side):
        if side is not None:
            path, entries = result
            _, edit, tree = self.panes[side]
            edit.setText(path); tree.clear()
            parent = QTreeWidgetItem(['..', '', '', ''])
            parent.setData(0, Qt.UserRole, (pp.dirname(path), True, True))
            tree.addTopLevelItem(parent)
            for a in sorted(entries, key=lambda a: (not stat.S_ISDIR(a.st_mode), a.filename.lower())):
                is_dir = stat.S_ISDIR(a.st_mode)
                item = QTreeWidgetItem([('▸ ' if is_dir else '') + a.filename, str(a.st_size),
                                        oct(stat.S_IMODE(a.st_mode)), f'{a.st_uid}:{a.st_gid}'])
                item.setData(0, Qt.UserRole, (pp.join(path, a.filename), is_dir, False))
                tree.addTopLevelItem(item)
            self.status.setText(f'{len(entries)} items · Double-click a folder to enter it.')
        else:
            for _, _, tree in self.panes:
                tree.clear()
            self.status.setText(result + ' · Browse again to refresh both folders.')

    def failed(self, message):
        self.status.setText(message)
        QMessageBox.warning(self, 'File operation failed', message)

    def finished(self):
        self.job.deleteLater(); self.job = None
        self.setEnabled(True)

    def act(self, op):
        combo, _, tree = self.panes[0]
        item = tree.currentItem()
        data = item.data(0, Qt.UserRole) if item else None
        if not data or data[2]:
            QMessageBox.information(self, 'Select an item', 'Select a file or folder in the left pane first.')
            return
        src = data[0]
        args = {'src': src}
        profiles = [self.profiles[combo.currentIndex()]]
        detail = profiles[0]['name'] + ':' + src
        if op in ('copy', 'move'):
            dest, path, _ = self.panes[1]
            if not path.text().startswith('/'):
                QMessageBox.information(self, 'Destination', 'Browse an absolute destination folder on the right first.')
                return
            profiles.append(self.profiles[dest.currentIndex()])
            args['dest_dir'] = path.text()
            detail += '\n→ ' + profiles[1]['name'] + ':' + pp.join(path.text(), pp.basename(src))
            detail += '\n\nExisting destinations are never overwritten. Folders include all descendants.'
            if op == 'move':
                detail += '\nThe source is removed after checksum verification. Stop processes editing the source before moving.'
        elif op == 'rename':
            name, ok = QInputDialog.getText(self, 'Rename', 'New filename (same folder):', text=pp.basename(src))
            if not ok:
                return
            if not name or '/' in name or name in ('.', '..') or '\x00' in name:
                QMessageBox.warning(self, 'Invalid name', 'Enter a single nonempty filename.'); return
            args['name'] = name; detail += '\nNew name: ' + name
        elif op == 'chmod':
            mode, ok = QInputDialog.getText(self, 'Permissions', 'Unix mode: e.g. 640 = owner read/write, group read; 750 = owner rwx, group r-x.\nFolders need execute permission for traversal. Applies to selected item only.')
            if not ok:
                return
            if len(mode) != 3 or any(c not in '01234567' for c in mode):
                QMessageBox.warning(self, 'Invalid mode', 'Enter three octal digits, such as 640 or 750.'); return
            args['mode'] = int(mode, 8); detail += '\nNew mode: ' + mode + ' (selected item only)'
        elif op == 'chown':
            owners, ok = QInputDialog.getText(self, 'Change owner', 'Numeric UID:GID, e.g. 1001:1001. Use id username in the VM terminal to look them up.\nRequires permission on the VM; no automatic sudo.')
            if not ok:
                return
            parts = owners.split(':')
            if len(parts) != 2 or not all(p.isascii() and p.isdigit() and int(p) < 4294967295 for p in parts):
                QMessageBox.warning(self, 'Invalid owner', 'Enter numeric UID:GID.'); return
            args.update(uid=int(parts[0]), gid=int(parts[1])); detail += '\nNew UID:GID: ' + owners
        elif op == 'delete':
            detail += '\n\nPermanently delete this item and ALL contents if it is a folder. No recycle bin.'
        if QMessageBox.question(self, 'Confirm ' + op, detail, QMessageBox.Yes | QMessageBox.No, QMessageBox.No) == QMessageBox.Yes:
            self.start(op, profiles, args)
