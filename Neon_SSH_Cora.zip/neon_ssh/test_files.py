import errno
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from file_manager import transfer, safe_path, snapshot, remove_tree

class LocalSFTP:
    """SFTP-shaped adapter; verifies algorithms using isolated temporary folders."""
    def __init__(self, root): self.root = Path(root)
    def p(self, path): return self.root / path.lstrip('/')
    def lstat(self, path): return self.p(path).lstat()
    def listdir_attr(self, path):
        return [SimpleNamespace(filename=p.name) for p in self.p(path).iterdir()]
    def open(self, path, mode): return self.p(path).open('xb' if mode == 'wx' else mode)
    def mkdir(self, path, mode): self.p(path).mkdir(mode=mode)
    def chmod(self, path, mode): self.p(path).chmod(mode)
    def remove(self, path): self.p(path).unlink()
    def rmdir(self, path): self.p(path).rmdir()

class TransferTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root=Path(self.tmp.name)
        (root/'a').mkdir(); (root/'b').mkdir()
        self.a=LocalSFTP(root/'a'); self.b=LocalSFTP(root/'b')
        self.a.p('/folder').mkdir()
        self.a.p('/folder/space name.txt').write_bytes(b'hello\0binary')
        self.a.p('/folder/empty').mkdir()
    def tearDown(self): self.tmp.cleanup()
    def test_copy_nested_and_no_overwrite(self):
        transfer(self.a,self.b,'/folder','/copy')
        self.assertEqual(self.b.p('/copy/space name.txt').read_bytes(),b'hello\0binary')
        self.assertTrue(self.a.p('/folder').exists())
        with self.assertRaises(ValueError): transfer(self.a,self.b,'/folder','/copy')
    def test_move_verifies_then_removes(self):
        transfer(self.a,self.b,'/folder','/moved',move=True)
        self.assertFalse(self.a.p('/folder').exists())
        self.assertTrue(self.b.p('/moved/empty').is_dir())
    def test_failed_verification_keeps_source(self):
        original=self.b.open
        def corrupt(path,mode):
            if mode=='rb': self.b.p(path).write_bytes(b'corrupt')
            return original(path,mode)
        self.b.open=corrupt
        with self.assertRaises(ValueError): transfer(self.a,self.b,'/folder','/bad',move=True)
        self.assertTrue(self.a.p('/folder/space name.txt').exists())
    def test_links_rejected_and_root_guard(self):
        self.a.p('/folder/link').symlink_to('/tmp')
        with self.assertRaises(ValueError): snapshot(self.a,'/folder')
        for path in ('/', '/a/..', 'relative'):
            with self.assertRaises(ValueError): safe_path(path)
    def test_delete_tree(self):
        records=snapshot(self.a,'/folder')
        remove_tree(self.a,'/folder',records)
        self.assertFalse(self.a.p('/folder').exists())
    def test_permission_error_not_treated_as_absence(self):
        def denied(path): raise PermissionError(errno.EACCES,'denied')
        self.b.lstat=denied
        with self.assertRaises(PermissionError): transfer(self.a,self.b,'/folder','/new')

if __name__=='__main__': unittest.main()
